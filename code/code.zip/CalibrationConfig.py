
corners_length = 2.1
square_length = 3
calibration_size = (7, 7)
save_path = 'calibration_images/'
calibration_param_path = 'calibration_param'
map_param_path = 'map_param'
